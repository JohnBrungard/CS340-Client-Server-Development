from pymongo import MongoClient

from bson.objectid import ObjectId

from pprint import pprint


class Crud(object):
    """ CRUD operations for MongoDB """

    def __init__(self, username, password, port, database, collection):

        # Initializing the MongoClient. This helps to

        # access the MongoDB databases and collections.

        self.client = MongoClient('mongodb://{}:{}@localhost:{}/{}'.format(username, password, port, database))

        self.database = self.client[database]
        self.collection = self.database[collection]

    # Create an insertion of data into the database

    def create(self, data):

        try:

            if data is not None and type(data) is dict and len(data) > 0:

                insertion_result = self.collection.insert(data)  # data should be dictionary

                pprint(insertion_result)  # Used to print complex data structures

                return True  # Insertion successful

            else:

                raise Exception("Nothing to save, because data parameter is empty or not properly formatted")

        except Exception as e:

            print("The following exception(s) occurred:", e)

            return False  # Insertion failed

    # Queries for document(s) in the database

    def read(self, data):

        try:

            if data is not None and type(data) is dict:  # Query contains data and is a dict

                search_result = self.collection.find(data, {'_id': False})

                # If cursor object returns with no documents:
                if search_result.count() == 0:
                    print("This query did not return any documents.")

                return search_result  # Returns resulting data

            else:

                raise Exception("Nothing to search, because data parameter is empty or not properly formatted")

        except Exception as e:

            print("The following exception(s) occurred:", e)

            return  # Returns nothing

    # Updates document(s) in the database

    def update(self, data, update_data):

        try:

            if data is not None and type(data) is dict and len(data) > 0:

                # update_data should be validated as well for update operations.

                if update_data is not None and type(update_data) is dict and len(update_data) > 0:

                    update_result = self.collection.update_many(data, {"$set": update_data})

                    # Write results in JSON formatting

                    json_format = "WriteResult({{\"nMatched\":{}, \"nUpserted\":{}, \"nModified\":{}}})".format(
                        update_result.matched_count, 0, update_result.modified_count)

                    return json_format

                else:

                    raise Exception("Nothing to update, because new data parameter is empty or not properly formatted")

            else:

                raise Exception("Nothing to update, because old data parameter is empty or not properly formatted")

        except Exception as e:

            print("The following exception(s) occurred:", e)

            return  # Returns nothing

    # Deletes document(s) in the database

    def delete(self, data):

        try:

            if data is not None and type(data) is dict:

                delete_result = self.collection.delete_many(data)

                # Write results in JSON formatting

                json_format = "{{\"acknowledged\":{}, \"deletedCount\":{}}}".format(True, delete_result.deleted_count)

                return json_format

            else:

                raise Exception("Nothing to delete, because data parameter is empty or not properly formatted")

        except Exception as e:

            print("The following exception(s) occurred:", e)

            return  # Returns nothing

